/*
 * Copyright 2010-2015 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Additions Copyright 2016 Espressif Systems (Shanghai) PTE LTD
 *
 * Licensed under the Apache License, Version 2.0 (the "License").
 * You may not use this file except in compliance with the License.
 * A copy of the License is located at
 *
 *  http://aws.amazon.com/apache2.0
 *
 * or in the "license" file accompanying this file. This file is distributed
 * on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either
 * express or implied. See the License for the specific language governing
 * permissions and limitations under the License.
 */

/**
 * @file aws_iot_certifcates.c
 * @brief File to store the AWS certificates in the form of arrays
 */

#ifdef __cplusplus
extern "C" {
#endif

const char aws_root_ca_pem[] = {"-----BEGIN CERTIFICATE-----\nMIIDQTCCAimgAwIBAgITBmyfz5m/jAo54vB4ikPmljZbyjANBgkqhkiG9w0BAQsF\nADA5MQswCQYDVQQGEwJVUzEPMA0GA1UEChMGQW1hem9uMRkwFwYDVQQDExBBbWF6\nb24gUm9vdCBDQSAxMB4XDTE1MDUyNjAwMDAwMFoXDTM4MDExNzAwMDAwMFowOTEL\nMAkGA1UEBhMCVVMxDzANBgNVBAoTBkFtYXpvbjEZMBcGA1UEAxMQQW1hem9uIFJv\nb3QgQ0EgMTCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALJ4gHHKeNXj\nca9HgFB0fW7Y14h29Jlo91ghYPl0hAEvrAIthtOgQ3pOsqTQNroBvo3bSMgHFzZM\n9O6II8c+6zf1tRn4SWiw3te5djgdYZ6k/oI2peVKVuRF4fn9tBb6dNqcmzU5L/qw\nIFAGbHrQgLKm+a/sRxmPUDgH3KKHOVj4utWp+UhnMJbulHheb4mjUcAwhmahRWa6\nVOujw5H5SNz/0egwLX0tdHA114gk957EWW67c4cX8jJGKLhD+rcdqsq08p8kDi1L\n93FcXmn/6pUCyziKrlA4b9v7LWIbxcceVOF34GfID5yHI9Y/QCB/IIDEgEw+OyQm\njgSubJrIqg0CAwEAAaNCMEAwDwYDVR0TAQH/BAUwAwEB/zAOBgNVHQ8BAf8EBAMC\nAYYwHQYDVR0OBBYEFIQYzIU07LwMlJQuCFmcx7IQTgoIMA0GCSqGSIb3DQEBCwUA\nA4IBAQCY8jdaQZChGsV2USggNiMOruYou6r4lK5IpDB/G/wkjUu0yKGX9rbxenDI\nU5PMCCjjmCXPI6T53iHTfIUJrU6adTrCC2qJeHZERxhlbI1Bjjt/msv0tadQ1wUs\nN+gDS63pYaACbvXy8MWy7Vu33PqUXHeeE6V/Uq2V8viTO96LXFvKWlJbYK8U90vv\no/ufQJVtMVT8QtPHRh8jrdkPSHCa2XV4cdFyQzR1bldZwgJcJmApzyMZFo6IQ6XU\n5MsI+yMRQ+hDKXJioaldXgjUkK642M4UwtBV8ob2xJNDd2ZhwLnoQdeXeGADbkpy\nrqXRfboQnoZsG4q5WTP468SQvvG5\n-----END CERTIFICATE-----"};

const char certificate_pem_crt[] = {"-----BEGIN CERTIFICATE-----\nMIIDWjCCAkKgAwIBAgIVANVzUL7taEbwnTOlk2NLWu6GPsV9MA0GCSqGSIb3DQEB\nCwUAME0xSzBJBgNVBAsMQkFtYXpvbiBXZWIgU2VydmljZXMgTz1BbWF6b24uY29t\nIEluYy4gTD1TZWF0dGxlIFNUPVdhc2hpbmd0b24gQz1VUzAeFw0yMDAyMTAwMTI5\nNThaFw00OTEyMzEyMzU5NTlaMB4xHDAaBgNVBAMME0FXUyBJb1QgQ2VydGlmaWNh\ndGUwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIBAQDOV7eOixID6opBC33J\n67lfgDZ156wF6p9rsV7soT/IzB9K9gyoBRWBhuMXmUYWCJl4ohrFEBiCiGona4RK\n3YUgOOQhRPyB8KqLmG6g/Rfm7pJmqzD469eqGSuyRzelahgZrXSgM3SYZ+xIQGwA\n8qsBJ5WQks82Wbk5eJK0gT+2z2qCvKiKfgThhdYejWqWZqk3Uot3JxvRTp2N+d7q\nIZxEHH92k8REsyCQzan5EahemQJIq7X6maaJmsGXcib8QTyJJv1HMSuTy3+aBZYw\nDxP2LJjeQxw4DanUP2OyPTdoMUiZJm9zJ6Zdk0JFqs2nsCZn1nxGiATru+HkgSzi\nQ6zbAgMBAAGjYDBeMB8GA1UdIwQYMBaAFLJvQvctvDFZNRLBpACYMxMeFedSMB0G\nA1UdDgQWBBS2MEVqAp+kCEGrHsQ2iH++0n8cLDAMBgNVHRMBAf8EAjAAMA4GA1Ud\nDwEB/wQEAwIHgDANBgkqhkiG9w0BAQsFAAOCAQEAWe5Dio5lKdcJe8e8lltSI6Lu\nP+sgddsROnQWaULQelkE31qJlJTHDkGqeUU64zVcv57gGWKCe4rRBECPVeDsjRk+\nqJOEVElTuuq9rd/VAot/d+4Pcflo5o6I79BXIkkaFAziz5AH1jefh3LcOrYq7ZYy\namYFYrk5Hj/1YKN05rKCQs5zErgXYp3J3fndKB+QQhAqqiBlhYU9thJghJuub1Pp\nzirawzccN5qfznIOhhB7Qq6aGmqi3a4JFerz3p3vLrTK4vRwoTXDe3IoyaMDbjQW\nDMB/3GtjGDI8VfyPEtmk73UU21IabxG3dDJuYVv+OcaPJV84/6s/XLtqCNy5Uw==\n-----END CERTIFICATE-----"};

const char private_pem_key[] = {"-----BEGIN RSA PRIVATE KEY-----\nMIIEpAIBAAKCAQEAzle3josSA+qKQQt9yeu5X4A2deesBeqfa7Fe7KE/yMwfSvYM\nqAUVgYbjF5lGFgiZeKIaxRAYgohqJ2uESt2FIDjkIUT8gfCqi5huoP0X5u6SZqsw\n+OvXqhkrskc3pWoYGa10oDN0mGfsSEBsAPKrASeVkJLPNlm5OXiStIE/ts9qgryo\nin4E4YXWHo1qlmapN1KLdycb0U6djfne6iGcRBx/dpPERLMgkM2p+RGoXpkCSKu1\n+pmmiZrBl3Im/EE8iSb9RzErk8t/mgWWMA8T9iyY3kMcOA2p1D9jsj03aDFImSZv\ncyemXZNCRarNp7AmZ9Z8RogE67vh5IEs4kOs2wIDAQABAoIBAQC5glMcbBt+Odai\nM9qbNroqCfLsfaRCjXVWNNjKlQ3rUNixZBRs2mVDVinEhaBlHsYblmHK2XWvpUUK\nu7bsN8v/9CXlY0hA6kXpytlrEx/yFnq4oyAcKqxx2L9YQH7e0Etqim9Xt+sTOhtL\nud9f2suy9guZNuPkUTYdXTFH5wuJJcGJAVAsmM168snzsCLWgPeyMFsO3fRuh2im\noTxRRl5ndWuAe8gYbleAi9+suf6X4rI0SOhjGWpoY1SfvDj+oun54WHInkde80gJ\nKC2av7qnrMLyRojrrLOPC883Twv0XX13FzigxcjuVdWYl9BNX2G8hUZEJ1CIplkK\nH3lYrZIBAoGBAP6Jvxb8tph98ubw8928Dtfzp2B8UZwIbIflwGNePYYWqCVOPtQ9\nO28/siw2YWOoCHtm+6glyQ2/lW0S2qqOANzwVQ1+1lzMXY+2nz2MRzW3+5A7PNK9\nrYWTx+G7P0c0DHUdYI8v9WjFJdKIdsptq9vvm6ZfuFUijYZ1bDoCXvshAoGBAM+H\nG496NJelyebXs4WGUGMHo73OISe4frZSXJON02dZaHOlHqQ8e1e2hPvdEDk8CJNL\ng+ywRnm07pN0Ag3QrAT1nKuB3PrvWyMIw8inwT2OAC+bF9OQ3/0P6UgK838VRYbA\nH5/+PcXv4vCHKghq/lnZ1l608VAhF2isz8NkpIR7AoGAKJ0gAXH3TKOkE1dVAgdU\nsv5ssYeEmgn6D0EIjpJl7LRGxhUTD1hp2Floe4d9yKHyIIaRFwZYazorhIjinR4l\nYxtx5sJbP9lYAGtaQz7Tye1+VUgub03Wlx66YPk4oorahgFW++HiHYJ/g3VExw3y\nwxgbVNOnHOZzgIXR6/ue3iECgYBsEABr78ifBrdhuwRCDTSivIGo/kMJeeqRacXH\nF9zzPf1D6sFP6CaZ//Kza+NcykP03yetAgVQrsRkh83h/7zzQCn6rL6y9BxS2+eG\n/sODGARExc/cXN4l2jkxSHKOxDbV+gj9uNfV0BouAVQD2iLkCqiz3Cij/vc/jG0L\nY8a/LQKBgQCPRlwuDrnVVRBMqBXSBwofvxseLZu8oESW8a3cL0/MnPfmeujmYLG+\nIY1rROhDBhc2Vyh1mg59lGjDbnZ5RIjCTLjYml//JELh6eWDKASAMx06lvxd+wgB\nObQB1rrDRkRNqudsuRkF69CZjGt8xE6sbgIVFzVqDRTVshdPDqRUAw==\n-----END RSA PRIVATE KEY-----\n"};

#ifdef __cplusplus
}
#endif
